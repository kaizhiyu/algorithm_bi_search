package com.example.sendtojs_demo;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

@Controller
public class GreetingController {    
    @Resource
    private SimpMessagingTemplate simpMessagingTemplate;

    @MessageMapping("/change-notice")
    public void greeting(String value){
        System.out.println("GreetingController.greeting===" + value);

        this.simpMessagingTemplate.convertAndSend("/topic/notice", value);
    }
}

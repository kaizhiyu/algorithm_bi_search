package com.example.by_hand_demo;

import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.AbstractWebSocketMessageBrokerConfigurer;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;

/**
 * xxx
 *
 * @author:v_fanhaibo on 2018/1/5.
 * @version:v1.0
 */

@Configuration
@EnableWebSocketMessageBroker
public class MessageBrokerConfigurer extends AbstractWebSocketMessageBrokerConfigurer{


    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/webSocket").setAllowedOrigins("*").withSockJS();
    }

    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        //订阅消息到页面
        //stompClient.subscribe('/topic/notice', function (data) {
        registry.enableSimpleBroker("/receiveFromServer");
        // 发送到后台
        //stompClient.send("/app/change-notice", {}, value);
        registry.setApplicationDestinationPrefixes("/app");
    }
}

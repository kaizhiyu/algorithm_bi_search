package com.example.by_hand_demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.RestController;

/**
 * xxx
 *
 * @author:v_fanhaibo on 2018/1/5.
 * @version:v1.0
 */

@RestController
public class SocketController {

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    // 发送到后台
    //stompClient.send("/app/change-notice", {}, value);
    @MessageMapping("/change-notice")
    public void sendMessage(String value){
        System.out.println(value);
        //payload 装载
        //发送到页面
        //stompClient.subscribe('/topic/notice', function (data) {
        simpMessagingTemplate.convertAndSend("/receiveFromServer/notice",value);

    }
}

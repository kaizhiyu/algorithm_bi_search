package com.example.by_hand_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ByHandDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ByHandDemoApplication.class, args);
	}
}

package com.example.websocket_demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.CopyOnWriteArraySet;

/**
 * Created by XuJijun on 2017-03-21.
 */
@ServerEndpoint("/cmd-websocket")
@Component
public class CmdWebSocket {
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static int onlineCount = 0;
    private static CopyOnWriteArraySet<CmdWebSocket> webSocketSet = new CopyOnWriteArraySet<>();

    private static Vector<Session> list = new Vector<>();
    @OnOpen
    public void onOpen(Session session) throws IOException {
        if (list.size() != 0){
            list.clear();
        }
        list.add(session);
        webSocketSet.add(this);
        logger.info("new connection...current online count: {}", getOnlineCount());
    }

    @OnClose
    public void onClose() throws IOException {
        webSocketSet.remove(this);
        decOnlineCount();
        logger.info("one connection closed...current online count: {}", getOnlineCount());
    }

    @OnMessage
    public void onMessage(String message, Session session) throws IOException, InterruptedException {
        logger.info("message received: {}", message);
        this.sendMessage("server response: " + message);

    }

    public void sendMessage(String message) throws IOException {
        list.get(0).getBasicRemote().sendText(message);
    }

    public static synchronized int getOnlineCount() {
        return CmdWebSocket.onlineCount;
    }

    public static synchronized void incrOnlineCount() {
        CmdWebSocket.onlineCount++;
    }

    public static synchronized void decOnlineCount() {
        CmdWebSocket.onlineCount--;
    }
}

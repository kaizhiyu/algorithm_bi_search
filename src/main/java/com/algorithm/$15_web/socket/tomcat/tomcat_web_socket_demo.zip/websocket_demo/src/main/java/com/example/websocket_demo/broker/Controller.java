package com.example.websocket_demo.broker;

import com.example.websocket_demo.CmdWebSocket;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

/**
 * xxx
 *
 * @author:v_fanhaibo on 2018/1/4.
 * @version:v1.0
 */

@RestController
public class Controller {

    @Autowired
    private CmdWebSocket cmdWebSocket;

    @GetMapping("/hand")
    public void hand() throws IOException {
        cmdWebSocket.sendMessage("controller send message to web socket....");

    }
}

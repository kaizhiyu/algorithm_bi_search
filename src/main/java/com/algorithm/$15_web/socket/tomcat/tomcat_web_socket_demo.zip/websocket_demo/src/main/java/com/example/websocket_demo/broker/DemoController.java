package com.example.websocket_demo.broker;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * xxx
 *
 * @author:v_fanhaibo on 2018/1/4.
 * @version:v1.0
 */

//http://blog.csdn.net/yingxiake/article/details/51213060
@Controller
@RequestMapping("/webSocket")
@MessageMapping("foo")
public class DemoController {

    @MessageMapping("handle")
    @SendTo("/topic/greetings")
    public String handle(String name) {
        System.out.println(name);
        //...
        return "handle2";
    }
}
